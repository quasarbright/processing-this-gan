import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class gravity extends PApplet {

ArrayList<Particle> particles = new ArrayList<Particle>();
int t, R, G, B;

float theta;
public void setup() {
  
  //size(1000, 1000);
  
  frameRate(600);
  background(0);
  strokeWeight(1);
  makeParticles(20000);
}

public void makeParticles(int quant) {
  for (int i = 0; i<=quant; i++) {
    particles.add(new Particle());
  }
}

public void draw() {
  if (frameRate<5)
    exit();
  t = millis()%1001;
  theta = .3f*map(t, 0, 1000, 0, 33);

  //if(millis()%1000<5)
  //  makeParticles(500);

  frame.setTitle("Gravity simulator                        " + PApplet.parseInt(frameRate) + " fps");
  background(0);
  fill(0);
  fill(0, 0, 255, 50);
  noStroke();
  ellipse(mouseX, mouseY, 2*prox, 2*prox);

  if (keyPressed)
    switch(key) {
    case 'f':
      prox = pi;
      break;
    case 't':
      prox = -pi;
      break;
    }

  for (Particle p : particles) {
    p.updatePos();
    if (mousePressed)
      switch(mouseButton) {
      case LEFT: 
        p.pullTo(mouseX, mouseY); 
        break;
      case RIGHT: 
        p.repelFrom(mouseX, mouseY);
        break;
      }
    if (keyPressed)
      switch(key) {
      case ' ':
        p.release();
        break;
      case 'a':
        p.stop();
        break;
      case 'r':
        p.randomize();
        break;
      case 'g':
        p.gp = 2;
        p.vmaxp = 1000;
        break;
      case 's':
        strokeWeight(5);
        break;
      }
    if (!keyPressed)
      switch(key) {
      case 'g':
        p.gp = g;
        p.vmaxp = vmax;
        break;
      case 's':
        strokeWeight(1);
        break;
      }
  }
}

/*
space sets releases (a = 0, v unchanged)
 a sets v = 0 and a = 0 (a = 0 indirectly)
 lclick attracts particles to mouse
 rclick repells particles from mouse
 g makes gravity 10
 t traps particles in blue circles
 f frees particles trapped in blue circle
 s increases stroke
 */
float g = 1;//mess with these
int vmax = 30;//mess with these
float prox = -100;//mess with these
float pi = prox;

class Particle {
  PVector p = new PVector(random(0, width), random(0, height));
  PVector v = new PVector(0, 0);
  PVector vp = new PVector(0, 0);
  PVector a = new PVector(0, 0);
  int c = floor(random(0, 255));
  float gp = g;
  int vmaxp = floor(vmax*g*2);
  float R = random(255);
  float G = random(255);
  float B = random(255);

  public void pullTo(int x, int y) {//destination coordinates
    if (dist(x, y, p.x, p.y)<prox) //dont want a velocity if it's at the puller
      //p = new PVector(random(0, width), random(0, height));
      stop();
    //release();
    else
      applyForce(x-p.x, y-p.y);
  }

  public void repelFrom(int x, int y) {
    applyForce(p.x-x, p.y-y);
  }

  public void applyForce(float x, float y) {    //force direction
    PVector force = new PVector(x, y);
    PVector unitForce = new PVector( x/force.mag(), y/force.mag() );
    a.x = gp*unitForce.x;
    a.y = gp*unitForce.y;
  }

  public void stop() {
    v.x = v.y = 0;
  }

  public void reverse() {
    v.x = -1*v.x;
    v.y = -1*v.y;
  }

  public void release() {
    a.x = a.y = 0;
  }

  public void randomize() {
    p = new PVector(random(0, width), random(0, height));
    v = new PVector(0, 0);
    a = new PVector(0, 0);
  }

  public void show() {
    //int whiteness = floor(map(1000*v.mag(), 0, 1000*vmaxp/sqrt(2), 255, 0));
    //stroke(255, whiteness, whiteness);

    //R = c+floor(127*sin(theta)+128);
    //G = c+floor(127*sin(theta+2)+128);
    //B = c+floor(127*sin(theta+4)+128);
    //R%=256;
    //G%=256;
    //B%=256;
    stroke(R, G, B);
    //stroke(0, 255, 0);
    point(p.x, p.y);
  }

  public void updatePos() {
    p.x+=v.x;
    p.y+=v.y;
    v.x+=a.x;
    v.y+=a.y;//moves with acceleration

    if (v.mag()>vmax)
      v.normalize().mult(vmax);

    if (p.x>=width)
      p.x = width;
    if (p.x<=0)
      p.x = 0;

    if (p.y>=height)
      p.y = height;
    if (p.y<=0)
      p.y = 0;
    show();
  }
}
  public void settings() {  fullScreen();  noSmooth(); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "--present", "--window-color=#0FF5FF", "--stop-color=#FF0D0D", "gravity" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
